# qb-mdt
A mdt for qbus

A new version for QBCORE
